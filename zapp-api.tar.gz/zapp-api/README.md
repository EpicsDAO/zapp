# zapp-api

Rust Serverless Framework

## Usage

Run PostgreSQL Docker
```bash
zapp docker psql
```

Run Server
```bash
cargo run
```

Access to GraphQL Playground

`http://localshost:3000/api/graphql`