use entity::async_graphql;

#[derive(async_graphql::MergedObject, Default)]
pub struct Query();